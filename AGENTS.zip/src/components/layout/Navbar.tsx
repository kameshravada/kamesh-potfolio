export default function Navbar() {
    return (
        <nav className="fixed top-0 w-full z-50 border-b border-white/10 bg-slate-900/60 backdrop-blur-xl">
            <div className="flex justify-between items-center h-20 px-8 max-w-7xl mx-auto">
                <div className="text-xl font-bold text-white font-headline">
                    KAMESH RAVADA
                </div>

                <div className="hidden md:flex gap-8 font-headline">
                    <a href="/systems" className="text-slate-400 hover:text-white">
                        Systems
                    </a>
                    <a href="/tech" className="text-slate-400 hover:text-white">
                        Tech
                    </a>
                    <a href="/process" className="text-slate-400 hover:text-white">
                        Process
                    </a>
                    <a href="/case-studies" className="text-slate-400 hover:text-white">
                        Case Studies
                    </a>
                </div>

                <button className="bg-gradient-to-br from-primary to-primary text-black px-6 py-2 rounded-lg font-bold">
                    Hire Me
                </button>
            </div>
        </nav>
    );
}