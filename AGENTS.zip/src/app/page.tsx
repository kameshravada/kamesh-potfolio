import Container from "@/components/ui/Container"

export default function Home() {
    return (
        // <main className="pt-24 ">
        //     <Container>
        //         <h1 className="text-5xl font-headline font-bold">
        //             I Build Scalable Systems
        //         </h1>
        //         <p className="text-on-surface-variant mt-4">
        //             Backend systems, AI integrations, and scalable architecture.
        //         </p>
        //     </Container>
        // </main>
        <div className="bg-red-500 text-white p-10 text-3xl">
            Tailwind Working Test
        </div>
    );
}