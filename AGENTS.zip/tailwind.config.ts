import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx}",
    "./src/components/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        background: "#0b0e14",
        primary: "#69daff",
        secondary: "#ac89ff",
        surface: "#161a21",
        "surface-variant": "#22262f",
        "on-surface": "#ecedf6",
        "on-surface-variant": "#a9abb3",
        outline: "#73757d",
      },
      fontFamily: {
        headline: ["Manrope"],
        body: ["Inter"],
        label: ["Space Grotesk"],
      },
    },
  },
  plugins: [],
};

export default config;